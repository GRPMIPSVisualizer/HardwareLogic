export default class Logic{
    pin1:number;
    pin2:number;
    outpin:number = 0;
    constructor(inputPin1:number,inputPin2:number){
        this.pin1 = inputPin1;
        this.pin2 = inputPin2;
    }
    toBinaryString(){
        
    }
}